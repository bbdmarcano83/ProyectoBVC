import uvicorn
import asyncio
import os
import json

from fastapi import FastAPI, Form, Request, Depends, Response
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from jinja2 import Environment, FileSystemLoader, select_autoescape
from sqlalchemy.orm import Session

from database import init_db, get_db, SessionLocal, AlertaPrecio
from services.alertas_worker import loop_alertas
from services.bvc import obtener_datos_bvc, obtener_detalle_profundo, obtener_historico, _to_float, formatear_bs, formatear_entero, formatear_millones, mercado_abierto
from services.portafolio import calcular_fila, resumen_portafolio
from services.auth import (
    crear_usuario, autenticar_usuario, crear_token,
    get_usuario_actual, require_usuario, require_suscripcion,
    suscripcion_activa, dias_restantes, hash_password
)
from services.pagos import crear_pago, verificar_firma_ipn, procesar_webhook, verificar_estado_pago
from database import ActivoPortafolio, Watchlist

app = FastAPI(title="Caracas Bull")

# ── Init DB al arrancar ────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    init_db()
    _crear_admin_si_no_existe()
    # Arrancar worker de alertas en background
    asyncio.create_task(loop_alertas())
    # Registrar webhook de Telegram
    await registrar_webhook_telegram()


def _crear_admin_si_no_existe():
    """Crea la cuenta admin en producción si no existe. Lee credenciales de variables de entorno."""
    import os
    from datetime import datetime, timedelta
    from services.auth import hash_password

    email    = os.environ.get("ADMIN_EMAIL", "")
    password = os.environ.get("ADMIN_PASSWORD", "")
    nombre   = os.environ.get("ADMIN_NOMBRE", "Admin")

    if not email or not password:
        return  # No configurado, saltar

    db = SessionLocal()
    try:
        from database import Usuario, Suscripcion
        if db.query(Usuario).filter(Usuario.email == email).first():
            return  # Ya existe

        usuario = Usuario(
            nombre=nombre,
            email=email,
            password_hash=hash_password(password),
            es_admin=True,
            activo=True,
        )
        db.add(usuario)
        db.flush()

        suscripcion = Suscripcion(
            usuario_id=usuario.id,
            plan="pro",
            activa=True,
            fecha_inicio=datetime.utcnow(),
            fecha_vence=datetime.utcnow() + timedelta(days=365 * 100),
        )
        db.add(suscripcion)
        db.commit()
        print(f"[startup] Admin creado: {email}")
    except Exception as e:
        print(f"[startup] Error creando admin: {e}")
        db.rollback()
    finally:
        db.close()

# ── Archivos estáticos ─────────────────────────────────────────────────────────
app.mount("/static", StaticFiles(directory="static"), name="static")

# ── Jinja2 ────────────────────────────────────────────────────────────────────
env = Environment(
    loader=FileSystemLoader("templates"),
    autoescape=select_autoescape(["html"]),
    auto_reload=True,
    cache_size=0,
)
env.filters["format_bs"] = formatear_bs
env.filters["format_entero"] = formatear_entero
env.filters["format_millones"] = formatear_millones

def render(template_name: str, context: dict) -> HTMLResponse:
    t = env.get_template(template_name)
    return HTMLResponse(t.render(**context))


# ── Auth ──────────────────────────────────────────────────────────────────────

@app.get("/landing", response_class=HTMLResponse)
async def landing_page(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    return render("landing.html", {"request": request, "usuario": usuario})


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if usuario:
        return RedirectResponse(url="/", status_code=302)
    return render("login.html", {"request": request, "error": None})

@app.post("/login", response_class=HTMLResponse)
async def login_post(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    usuario = autenticar_usuario(db, email, password)
    if not usuario:
        return render("login.html", {"request": request, "error": "Email o contraseña incorrectos"})
    
    token = crear_token({"sub": str(usuario.id)})
    response = RedirectResponse(url="/", status_code=303)
    response.set_cookie("access_token", token, httponly=True, max_age=60*60*24*7, samesite="lax")
    return response

@app.get("/registro", response_class=HTMLResponse)
async def registro_page(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if usuario:
        return RedirectResponse(url="/", status_code=302)
    return render("registro.html", {"request": request, "error": None})

@app.post("/registro", response_class=HTMLResponse)
async def registro_post(
    request: Request,
    nombre: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    password2: str = Form(...),
    db: Session = Depends(get_db),
):
    if password != password2:
        return render("registro.html", {"request": request, "error": "Las contraseñas no coinciden"})
    if len(password) < 8:
        return render("registro.html", {"request": request, "error": "La contraseña debe tener al menos 8 caracteres"})
    try:
        usuario = crear_usuario(db, nombre, email, password)
    except ValueError as e:
        return render("registro.html", {"request": request, "error": str(e)})
    
    token = crear_token({"sub": str(usuario.id)})
    response = RedirectResponse(url="/", status_code=303)
    response.set_cookie("access_token", token, httponly=True, max_age=60*60*24*7, samesite="lax")
    return response

@app.get("/logout")
async def logout():
    response = RedirectResponse(url="/", status_code=302)
    response.delete_cookie("access_token")
    return response


# ── Suscripción ───────────────────────────────────────────────────────────────

@app.get("/suscripcion", response_class=HTMLResponse)
async def suscripcion_page(request: Request, mensaje: str = None, db: Session = Depends(get_db)):
    usuario = require_usuario(request, db)
    if isinstance(usuario, RedirectResponse):
        return usuario
    return render("suscripcion.html", {
        "request": request,
        "usuario": usuario,
        "activa": suscripcion_activa(usuario),
        "dias": dias_restantes(usuario),
        "pago": None,
        "mensaje": mensaje,
        "active": "",
    })

@app.post("/suscripcion/pagar")
async def suscripcion_pagar(
    request: Request,
    plan: str = Form(...),
    db: Session = Depends(get_db),
):
    usuario = require_usuario(request, db)
    if isinstance(usuario, RedirectResponse):
        return usuario

    pago = await crear_pago(usuario.id, plan, usuario.email)

    return render("suscripcion.html", {
        "request": request,
        "usuario": usuario,
        "activa": suscripcion_activa(usuario),
        "dias": dias_restantes(usuario),
        "pago": pago,
        "mensaje": None,
        "active": "",
    })

@app.get("/suscripcion/estado/{payment_id}")
async def estado_pago(payment_id: str):
    datos = await verificar_estado_pago(payment_id)
    if datos:
        return JSONResponse({"status": datos.get("payment_status", "waiting")})
    return JSONResponse({"status": "waiting"})

@app.get("/suscripcion/exitosa", response_class=HTMLResponse)
async def suscripcion_exitosa(request: Request, db: Session = Depends(get_db)):
    return RedirectResponse(url="/suscripcion?mensaje=¡Pago recibido! Tu suscripción será activada en minutos.", status_code=302)

@app.post("/webhook/nowpayments")
async def webhook_nowpayments(request: Request, db: Session = Depends(get_db)):
    body = await request.body()
    firma = request.headers.get("x-nowpayments-sig", "")
    if not verificar_firma_ipn(body, firma):
        return JSONResponse({"error": "firma inválida"}, status_code=400)
    datos = json.loads(body)
    procesar_webhook(db, datos)
    return JSONResponse({"ok": True})


# ── Pizarra ───────────────────────────────────────────────────────────────────

@app.api_route("/", methods=["GET", "HEAD"], response_class=HTMLResponse)
async def index(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    return render("landing.html", {"request": request, "usuario": usuario})


@app.get("/pizarra", response_class=HTMLResponse)
async def pizarra(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/", status_code=302)
    if not suscripcion_activa(usuario):
        return RedirectResponse(url="/suscripcion", status_code=302)

    datos = await obtener_datos_bvc()
    return render("pizarra.html", {
        "request": request,
        "datos": datos,
        "active": "pizarra",
        "usuario": usuario,
        "dias": dias_restantes(usuario),
        "mercado": mercado_abierto(),
    })


# ── Portafolio ────────────────────────────────────────────────────────────────

@app.get("/portafolio", response_class=HTMLResponse)
async def ver_portafolio(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    if not suscripcion_activa(usuario):
        return RedirectResponse(url="/suscripcion", status_code=302)

    datos_bolsa = await obtener_datos_bvc()
    config_tasa = float(os.environ.get("TASA_BCV", "0"))

    activos_db = db.query(ActivoPortafolio).filter(ActivoPortafolio.usuario_id == usuario.id).all()
    portafolio = {
        a.simbolo: {
            "cantidad": a.cantidad,
            "precio_promedio": a.precio_promedio,
            "comision": a.comision,
            "registro": a.registro,
            "iva": a.iva,
        }
        for a in activos_db
    }

    mapa_precios = {item["COD_SIMB"]: _to_float(item.get("PRECIO") or 0) for item in datos_bolsa}
    total_mkt = sum(
        _to_float(d.get("cantidad")) * mapa_precios.get(simb, _to_float(d.get("precio_promedio")))
        for simb, d in portafolio.items()
    )

    filas = [
        calcular_fila(simb, d, mapa_precios.get(simb, _to_float(d.get("precio_promedio"))), total_mkt, config_tasa)
        for simb, d in portafolio.items()
    ]
    resumen = resumen_portafolio(portafolio, datos_bolsa, config_tasa)

    return render("portafolio.html", {
        "request": request,
        "filas": filas,
        "resumen": resumen,
        "tasa": config_tasa,
        "labels": [f["simb"] for f in filas],
        "valores": [round(f["val_mkt"], 2) for f in filas],
        "ganancias": [round(f["ganancia"], 2) for f in filas],
        "active": "portafolio",
        "usuario": usuario,
        "dias": dias_restantes(usuario),
        "mercado": mercado_abierto(),
    })

@app.post("/configurar")
async def configurar(tasa: float = Form(...), request: Request = None, db: Session = Depends(get_db)):
    os.environ["TASA_BCV"] = str(tasa)
    return RedirectResponse(url="/portafolio", status_code=303)

@app.post("/agregar")
async def agregar(
    request: Request,
    simb: str = Form(...), cant: float = Form(...), precio: float = Form(...),
    com: float = Form(0), reg: float = Form(0), iva: float = Form(16),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    existente = db.query(ActivoPortafolio).filter(
        ActivoPortafolio.usuario_id == usuario.id,
        ActivoPortafolio.simbolo == simb.upper()
    ).first()
    if existente:
        existente.cantidad = cant
        existente.precio_promedio = precio
        existente.comision = com
        existente.registro = reg
        existente.iva = iva
    else:
        db.add(ActivoPortafolio(
            usuario_id=usuario.id, simbolo=simb.upper(),
            cantidad=cant, precio_promedio=precio, comision=com, registro=reg, iva=iva
        ))
    db.commit()
    return RedirectResponse(url="/portafolio", status_code=303)

@app.post("/editar")
async def editar(
    request: Request,
    simb: str = Form(...), cant: float = Form(...), precio: float = Form(...),
    com: float = Form(0), reg: float = Form(0), iva: float = Form(16),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    activo = db.query(ActivoPortafolio).filter(
        ActivoPortafolio.usuario_id == usuario.id,
        ActivoPortafolio.simbolo == simb.upper()
    ).first()
    if activo:
        activo.cantidad = cant
        activo.precio_promedio = precio
        activo.comision = com
        activo.registro = reg
        activo.iva = iva
        db.commit()
    return RedirectResponse(url="/portafolio", status_code=303)

@app.post("/eliminar")
async def eliminar(request: Request, simb: str = Form(...), db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    activo = db.query(ActivoPortafolio).filter(
        ActivoPortafolio.usuario_id == usuario.id,
        ActivoPortafolio.simbolo == simb.upper()
    ).first()
    if activo:
        db.delete(activo)
        db.commit()
    return RedirectResponse(url="/portafolio", status_code=303)


# ── Detalle ───────────────────────────────────────────────────────────────────

@app.get("/detalle/{simbolo}", response_class=HTMLResponse)
async def ver_detalle(request: Request, simbolo: str, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    if not suscripcion_activa(usuario):
        return RedirectResponse(url="/suscripcion", status_code=302)

    simbolo = simbolo.upper()
    datos_bolsa, prof, historico = await asyncio.gather(
        obtener_datos_bvc(), obtener_detalle_profundo(simbolo), obtener_historico(simbolo)
    )
    activo = next((i for i in datos_bolsa if i.get("COD_SIMB") == simbolo), {})

    series_data = []
    volume_data = []
    for m in reversed(historico):
        o = _to_float(m.get("PRECIO_APERT"))
        h = _to_float(m.get("PRECIO_MAX"))
        l = _to_float(m.get("PRECIO_MIN"))
        c = _to_float(m.get("PRECIO_CIE"))
        # TOT_ACC_NEGOC = titulos negociados, TOT_MONTO_NEGOC = monto en Bs
        v     = _to_float(m.get("TOT_ACC_NEGOC") or 0)
        monto = _to_float(m.get("TOT_MONTO_NEGOC") or 0)
        ops   = _to_float(m.get("TOT_OP_NEGOC") or 0)
        fecha = m.get("FEC", "")
        if any([o, h, l, c]):
            series_data.append({"x": fecha, "y": [o, h, l, c]})
            volume_data.append({"x": fecha, "y": v, "monto": monto, "ops": int(ops), "isUp": c >= o})

    # Vela del dia en curso
    from datetime import datetime
    try:
        import pytz
        vet = pytz.timezone("America/Caracas")
        hoy = datetime.now(vet).strftime("%d/%m/%Y")
    except Exception:
        from datetime import timezone, timedelta
        hoy = datetime.now(timezone(timedelta(hours=-4))).strftime("%d/%m/%Y")

    precio_actual = _to_float(activo.get("PRECIO"))
    apert  = _to_float(prof.get("HOY_APERT") or precio_actual)
    maximo = _to_float(prof.get("HOY_MAX")   or precio_actual)
    minimo = _to_float(prof.get("HOY_MIN")   or precio_actual)
    vol_hoy = _to_float(activo.get("VOLUMEN") or 0)

    vela_hoy = None
    if precio_actual > 0:
        vela_hoy = {"x": hoy, "y": [apert, maximo, minimo, precio_actual]}

    vol_hoy_data = None
    if vol_hoy > 0:
        vol_hoy_data = {"x": hoy, "y": vol_hoy, "isUp": precio_actual >= apert}

    return render("detalle.html", {
        "request": request, "simbolo": simbolo, "activo": activo,
        "prof": prof, "series_data": series_data,
        "volume_data": volume_data,
        "vela_hoy": vela_hoy,
        "vol_hoy_data": vol_hoy_data,
        "active": "",
        "usuario": usuario, "dias": dias_restantes(usuario),
        "mercado": mercado_abierto(),
    })


# ── Perfil ───────────────────────────────────────────────────────────────────────

@app.get("/perfil", response_class=HTMLResponse)
async def ver_perfil(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    return render("perfil.html", {
        "request": request,
        "usuario": usuario,
        "dias": dias_restantes(usuario),
        "mercado": mercado_abierto(),
        "active": "",
        "msg_info": None, "msg_pass": None,
        "error_pass": False,
    })


@app.post("/perfil/info")
async def actualizar_info(
    request: Request,
    nombre: str = Form(...),
    email: str = Form(...),
    broker: str = Form(""),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    usuario.nombre = nombre.strip()
    usuario.email  = email.strip().lower()
    db.commit()
    return render("perfil.html", {
        "request": request, "usuario": usuario,
        "dias": dias_restantes(usuario), "mercado": mercado_abierto(),
        "active": "", "msg_info": "Datos actualizados correctamente",
        "msg_pass": None, "error_pass": False,
    })


@app.post("/perfil/password")
async def cambiar_password(
    request: Request,
    password_actual: str = Form(...),
    password_nueva: str = Form(...),
    password_nueva2: str = Form(...),
    db: Session = Depends(get_db),
):
    from services.auth import verificar_password, hash_password
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)

    if not verificar_password(password_actual, usuario.password_hash):
        return render("perfil.html", {
            "request": request, "usuario": usuario,
            "dias": dias_restantes(usuario), "mercado": mercado_abierto(),
            "active": "", "msg_info": None,
            "msg_pass": "Contraseña actual incorrecta", "error_pass": True,
        })
    if password_nueva != password_nueva2:
        return render("perfil.html", {
            "request": request, "usuario": usuario,
            "dias": dias_restantes(usuario), "mercado": mercado_abierto(),
            "active": "", "msg_info": None,
            "msg_pass": "Las contraseñas nuevas no coinciden", "error_pass": True,
        })
    if len(password_nueva) < 8:
        return render("perfil.html", {
            "request": request, "usuario": usuario,
            "dias": dias_restantes(usuario), "mercado": mercado_abierto(),
            "active": "", "msg_info": None,
            "msg_pass": "La contraseña debe tener al menos 8 caracteres", "error_pass": True,
        })

    usuario.password_hash = hash_password(password_nueva)
    db.commit()
    return render("perfil.html", {
        "request": request, "usuario": usuario,
        "dias": dias_restantes(usuario), "mercado": mercado_abierto(),
        "active": "", "msg_info": None,
        "msg_pass": "Contraseña cambiada correctamente", "error_pass": False,
    })


@app.post("/perfil/eliminar")
async def eliminar_cuenta(
    request: Request,
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    from services.auth import verificar_password
    usuario = get_usuario_actual(request, db)
    if not usuario or not verificar_password(password, usuario.password_hash):
        return RedirectResponse(url="/perfil", status_code=302)
    db.delete(usuario)
    db.commit()
    response = RedirectResponse(url="/", status_code=302)
    response.delete_cookie("access_token")
    return response


# ── Telegram ─────────────────────────────────────────────────────────────────────

@app.post("/telegram/vincular")
async def vincular_telegram(request: Request, db: Session = Depends(get_db)):
    import random, string
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return JSONResponse({"error": "no autorizado"}, status_code=401)
    # Generar código de 6 dígitos
    codigo = "".join(random.choices(string.digits, k=6))
    usuario.telegram_codigo = codigo
    db.commit()
    return JSONResponse({"codigo": codigo, "bot": "@CaracasBullBot"})


@app.post("/webhook/telegram")
async def webhook_telegram(request: Request, db: Session = Depends(get_db)):
    from services.telegram import verificar_codigo
    datos = await request.json()
    mensaje = datos.get("message", {})
    chat_id = str(mensaje.get("chat", {}).get("id", ""))
    texto   = mensaje.get("text", "").strip()

    if not chat_id:
        return JSONResponse({"ok": True})

    if texto.startswith("/start "):
        codigo = texto.replace("/start ", "").strip()
        await verificar_codigo(chat_id, codigo, db)
    elif texto == "/start":
        from services.telegram import enviar_mensaje
        msg = "Bienvenido a CaracasBull. Ve a tu perfil y haz clic en Vincular Telegram."
        await enviar_mensaje(chat_id, msg)
    elif texto == "/status":
        from services.telegram import enviar_mensaje
        from database import Usuario as UsuarioModel
        u = db.query(UsuarioModel).filter(UsuarioModel.telegram_chat_id == chat_id).first()
        if u:
            plan = u.suscripcion.plan if u.suscripcion else "trial"
            await enviar_mensaje(chat_id, f"Cuenta vinculada: {u.nombre} | Plan: {plan}")
        else:
            await enviar_mensaje(chat_id, "No hay cuenta vinculada a este chat.")

    return JSONResponse({"ok": True})


# ── Alertas ───────────────────────────────────────────────────────────────────────

@app.get("/alertas", response_class=HTMLResponse)
async def ver_alertas(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    alertas = db.query(AlertaPrecio).filter(
        AlertaPrecio.usuario_id == usuario.id
    ).order_by(AlertaPrecio.creado_en.desc()).all()
    datos_bolsa = await obtener_datos_bvc()
    simbolos = sorted([item["COD_SIMB"] for item in datos_bolsa])
    return render("alertas.html", {
        "request": request, "usuario": usuario,
        "alertas": alertas, "simbolos": simbolos,
        "dias": dias_restantes(usuario),
        "mercado": mercado_abierto(), "active": "",
    })


@app.post("/alertas/crear")
async def crear_alerta(
    request: Request,
    simbolo:    str   = Form(...),
    tipo:       str   = Form(...),
    porcentaje: float = Form(...),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    db.add(AlertaPrecio(
        usuario_id=usuario.id,
        simbolo=simbolo.upper(),
        tipo=tipo,
        porcentaje=porcentaje,
        activa=True,
        disparada=False,
    ))
    db.commit()
    return RedirectResponse(url="/alertas", status_code=303)


@app.post("/alertas/eliminar")
async def eliminar_alerta(
    request: Request,
    alerta_id: int = Form(...),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    alerta = db.query(AlertaPrecio).filter(
        AlertaPrecio.id == alerta_id,
        AlertaPrecio.usuario_id == usuario.id,
    ).first()
    if alerta:
        db.delete(alerta)
        db.commit()
    return RedirectResponse(url="/alertas", status_code=303)


@app.post("/alertas/reset")
async def reset_alerta(
    request: Request,
    alerta_id: int = Form(...),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    alerta = db.query(AlertaPrecio).filter(
        AlertaPrecio.id == alerta_id,
        AlertaPrecio.usuario_id == usuario.id,
    ).first()
    if alerta:
        alerta.disparada = False
        db.commit()
    return RedirectResponse(url="/alertas", status_code=303)


# ── Telegram ─────────────────────────────────────────────────────────────────────

@app.post("/telegram/vincular")
async def vincular_telegram(request: Request, db: Session = Depends(get_db)):
    import random, string
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return JSONResponse({"error": "no autorizado"}, status_code=401)
    codigo = "".join(random.choices(string.digits, k=6))
    usuario.telegram_codigo = codigo
    db.commit()
    return JSONResponse({"codigo": codigo, "bot": "@CaracasBullBot"})


@app.post("/webhook/telegram")
async def webhook_telegram(request: Request, db: Session = Depends(get_db)):
    from services.telegram import verificar_codigo, enviar_mensaje
    from database import Usuario as UsuarioModel
    datos = await request.json()
    mensaje = datos.get("message", {})
    chat_id = str(mensaje.get("chat", {}).get("id", ""))
    texto   = mensaje.get("text", "").strip()
    if not chat_id:
        return JSONResponse({"ok": True})
    if texto.startswith("/start "):
        codigo = texto.replace("/start ", "").strip()
        await verificar_codigo(chat_id, codigo, db)
    elif texto == "/start":
        bienvenida = "Bienvenido a CaracasBull. Ve a tu perfil y haz clic en Vincular Telegram."
        await enviar_mensaje(chat_id, bienvenida)
    elif texto == "/status":
        u = db.query(UsuarioModel).filter(UsuarioModel.telegram_chat_id == chat_id).first()
        if u:
            plan = u.suscripcion.plan if u.suscripcion else "trial"
            await enviar_mensaje(chat_id, f"Cuenta vinculada: {u.nombre} | Plan: {plan}")
        else:
            await enviar_mensaje(chat_id, "No hay cuenta vinculada a este chat.")
    return JSONResponse({"ok": True})


# ── Alertas ───────────────────────────────────────────────────────────────────────

@app.get("/alertas", response_class=HTMLResponse)
async def ver_alertas(request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    alertas = db.query(AlertaPrecio).filter(
        AlertaPrecio.usuario_id == usuario.id
    ).order_by(AlertaPrecio.creado_en.desc()).all()
    datos_bolsa = await obtener_datos_bvc()
    simbolos = sorted([item["COD_SIMB"] for item in datos_bolsa])
    return render("alertas.html", {
        "request": request, "usuario": usuario,
        "alertas": alertas, "simbolos": simbolos,
        "dias": dias_restantes(usuario),
        "mercado": mercado_abierto(), "active": "",
    })


@app.post("/alertas/crear")
async def crear_alerta(
    request: Request,
    simbolo:    str   = Form(...),
    tipo:       str   = Form(...),
    porcentaje: float = Form(...),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    db.add(AlertaPrecio(
        usuario_id=usuario.id,
        simbolo=simbolo.upper(),
        tipo=tipo,
        porcentaje=porcentaje,
        activa=True,
        disparada=False,
    ))
    db.commit()
    return RedirectResponse(url="/alertas", status_code=303)


@app.post("/alertas/eliminar")
async def eliminar_alerta(
    request: Request,
    alerta_id: int = Form(...),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    alerta = db.query(AlertaPrecio).filter(
        AlertaPrecio.id == alerta_id,
        AlertaPrecio.usuario_id == usuario.id,
    ).first()
    if alerta:
        db.delete(alerta)
        db.commit()
    return RedirectResponse(url="/alertas", status_code=303)


@app.post("/alertas/reset")
async def reset_alerta(
    request: Request,
    alerta_id: int = Form(...),
    db: Session = Depends(get_db),
):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return RedirectResponse(url="/login", status_code=302)
    alerta = db.query(AlertaPrecio).filter(
        AlertaPrecio.id == alerta_id,
        AlertaPrecio.usuario_id == usuario.id,
    ).first()
    if alerta:
        alerta.disparada = False
        db.commit()
    return RedirectResponse(url="/alertas", status_code=303)


# ── API endpoints ────────────────────────────────────────────────────────────────

@app.get("/api/precio/{simbolo}")
async def api_precio(simbolo: str, request: Request, db: Session = Depends(get_db)):
    usuario = get_usuario_actual(request, db)
    if not usuario:
        return JSONResponse({"error": "no autorizado"}, status_code=401)
    datos = await obtener_datos_bvc()
    activo = next((i for i in datos if i.get("COD_SIMB") == simbolo.upper()), None)
    if not activo:
        return JSONResponse({"error": "no encontrado"}, status_code=404)
    return JSONResponse({
        "precio":  _to_float(activo.get("PRECIO")),
        "var_rel": _to_float(activo.get("VAR_REL")),
        "var_abs": _to_float(activo.get("VAR_ABS")),
    })


# ── Setup Telegram webhook ───────────────────────────────────────────────────────

async def registrar_webhook_telegram():
    """Registra el webhook de Telegram al arrancar la app."""
    import os
    app_url = os.environ.get("APP_URL", "")
    if not app_url:
        return
    webhook_url = f"{app_url}/webhook/telegram"
    from services.telegram import TELEGRAM_API
    async with httpx.AsyncClient() as client:
        try:
            r = await client.post(f"{TELEGRAM_API}/setWebhook", json={"url": webhook_url})
            if r.status_code == 200:
                print(f"[Telegram] Webhook registrado: {webhook_url}")
        except Exception as e:
            print(f"[Telegram] Error registrando webhook: {e}")


# ── Inicio ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
